A Cython implementation of the polarimetric SAR speckle filter described by [Lee (1999)](https://ieeexplore.ieee.org/stamp/stamp.jsp?arnumber=789635).
The code was built using the [documentation and pseudocode provdied by PCI](http://www.pcigeomatics.com/geomatica-help/references/pciFunction_r/python/P_pspolfil.html)

